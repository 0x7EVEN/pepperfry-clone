export const icons = [
  {
    title: "MODERN DESIGN AESTHETICS",
    icon:
      "https://ii1.pepperfry.com/media/catalog/product/brands/1522331445casa-icon-1.jpg"
  },
  {
    title: " MONTHS WARRANTY",
    icon:
      "https://ii1.pepperfry.com/media/catalog/product/brands/1522331445casa-icon-2.jpg"
  },
  {
    title: "SIGNATURE COLLECTIONS",
    icon:
      "https://ii1.pepperfry.com/media/catalog/product/brands/1528443042casa_icon_03_08may.jpg"
  },
  {
    title: "UBER CHIC, UBER COMFORTABLE STYLES",
    icon:
      "https://ii1.pepperfry.com/media/catalog/product/brands/1522331446casa-icon-4.jpg"
  }
];
