export const Chairs = [
  {
    pic:
      "https://ii2.pepperfry.com/media/catalog/product/b/u/236x260/buena-lounge-chair-in-navy-blue-colour-buena-lounge-chair-in-navy-blue-colour-pspmpq.jpg",
    title: "Eva Upholstery Wing Chair In Red Colour",
    subtitle: "CasaCraft By Pepperfry",
    price: "42,999",
    discount: "52",
    id: 1
  },
  {
    pic:
      "https://ii2.pepperfry.com/media/catalog/product/b/u/236x260/buena-lounge-chair-in-navy-blue-colour-buena-lounge-chair-in-navy-blue-colour-pspmpq.jpg",
    title: "Eva Upholstery Wing Chair In Red Colour",
    subtitle: "CasaCraft By Pepperfry",
    price: "42,999",
    discount: "52",
    id: 2
  },
  {
    pic:
      "https://ii2.pepperfry.com/media/catalog/product/b/u/236x260/buena-lounge-chair-in-navy-blue-colour-buena-lounge-chair-in-navy-blue-colour-pspmpq.jpg",
    title: "Eva Upholstery Wing Chair In Red Colour",
    subtitle: "CasaCraft By Pepperfry",
    price: "42,999",
    discount: "52",
    id: 3
  },
  {
    pic:
      "https://ii2.pepperfry.com/media/catalog/product/b/u/236x260/buena-lounge-chair-in-navy-blue-colour-buena-lounge-chair-in-navy-blue-colour-pspmpq.jpg",
    title: "Eva Upholstery Wing Chair In Red Colour",
    subtitle: "CasaCraft By Pepperfry",
    price: "42,999",
    discount: "52",
    id: 4
  },
  {
    pic:
      "https://ii2.pepperfry.com/media/catalog/product/b/u/236x260/buena-lounge-chair-in-navy-blue-colour-buena-lounge-chair-in-navy-blue-colour-pspmpq.jpg",
    title: "Eva Upholstery Wing Chair In Red Colour",
    subtitle: "CasaCraft By Pepperfry",
    price: "42,999",
    discount: "52",
    id: 5
  },
  {
    pic:
      "https://ii2.pepperfry.com/media/catalog/product/b/u/236x260/buena-lounge-chair-in-navy-blue-colour-buena-lounge-chair-in-navy-blue-colour-pspmpq.jpg",
    title: "Eva Upholstery Wing Chair In Red Colour",
    subtitle: "CasaCraft By Pepperfry",
    price: "42,999",
    discount: "52",
    id: 6
  },
  {
    pic:
      "https://ii2.pepperfry.com/media/catalog/product/b/u/236x260/buena-lounge-chair-in-navy-blue-colour-buena-lounge-chair-in-navy-blue-colour-pspmpq.jpg",
    title: "Eva Upholstery Wing Chair In Red Colour",
    subtitle: "CasaCraft By Pepperfry",
    price: "42,999",
    discount: "52",
    id: 7
  },
  {
    pic:
      "https://ii2.pepperfry.com/media/catalog/product/b/u/236x260/buena-lounge-chair-in-navy-blue-colour-buena-lounge-chair-in-navy-blue-colour-pspmpq.jpg",
    title: "Eva Upholstery Wing Chair In Red Colour",
    subtitle: "CasaCraft By Pepperfry",
    price: "42,999",
    discount: "52",
    id: 8
  },
  {
    pic:
      "https://ii2.pepperfry.com/media/catalog/product/b/u/236x260/buena-lounge-chair-in-navy-blue-colour-buena-lounge-chair-in-navy-blue-colour-pspmpq.jpg",
    title: "Eva Upholstery Wing Chair In Red Colour",
    subtitle: "CasaCraft By Pepperfry",
    price: "42,999",
    discount: "52",
    id: 9
  }
];
