export const Groups = [
  {
    link:
      "https://ii1.pepperfry.com/media/catalog/product/collections/1600695896_malena.jpg",
    title: "MALENA",
    description: "Mid-Century Design With Tufted High Back"
  },

  {
    link:
      "https://ii1.pepperfry.com/media/catalog/product/collections/1624516903_evelyn.jpg",
    title: "EVELYN",
    description: "Soft anf Stout"
  },
  {
    link:
      "https://ii1.pepperfry.com/media/catalog/product/collections/1624529097_faye.jpg",
    title: "FAYE",
    description: "Modern Monotones "
  },
  {
    link:
      "https://ii1.pepperfry.com/media/catalog/product/collections/1626087460_unnamed.jpg",
    title: "ELINA",
    description: "Comfy Glam"
  },
  {
    link:
      "https://ii1.pepperfry.com/media/catalog/product/collections/1610766998_lara.jpg",
    title: "LARA",
    description: "Leisure And Luxury"
  },
  {
    link:
      "https://ii1.pepperfry.com/media/catalog/product/collections/1610766956_fuego.jpg",
    title: "FUEGO",
    description: "Soul Of Retro Design"
  },
  {
    link:
      "https://ii1.pepperfry.com/media/catalog/product/collections/1610767130_santiago.jpg",
    title: "SANTIAGO",
    description: "Soul Of Retro Design"
  },
  {
    link:
      "https://ii1.pepperfry.com/media/catalog/product/collections/1610766784_belem.jpg",
    title: "BELEM",
    description: "Mid Century Features"
  },
  {
    link:
      "https://ii1.pepperfry.com/media/catalog/product/collections/1600696063_cielo.jpg",
    title: "CIELO",
    description: "Neat Silhoutte"
  },
  {
    link:
      "https://ii1.pepperfry.com/media/catalog/product/collections/1610766828_cordoba.jpg",
    title: "CORDOBA",
    description: "Neat Silhoutte"
  },
  {
    link:
      "https://ii1.pepperfry.com/media/catalog/product/collections/1610766739_amelia.jpg",
    title: "AMELIA",
    description: "Perfect For Small Spaces"
  },
  {
    link:
      "https://ii1.pepperfry.com/media/catalog/product/collections/1610767048_mia.jpg",
    title: "MIA",
    description: "Showstopper Design"
  }
];
