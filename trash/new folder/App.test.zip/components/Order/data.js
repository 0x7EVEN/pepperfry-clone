export const data = [
  {
    img:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRTd5_GlunIvEbpDZYazRIvAIUlpaslhXTcOw&usqp=CAU",
    title: "Serena 3 seater Sofa In Blue Colour - CasaCraft By Pepperfry",
    qty: 1,
    price: "23,399",
    date: "2 Oct"
  }
];
