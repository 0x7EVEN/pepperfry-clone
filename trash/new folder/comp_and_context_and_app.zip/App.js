import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Home from "./components/home/Home";
import Item from './components/items/item';
import {useState} from 'react';
import {Route, Switch} from "react-router-dom";
import Products from "./components/productList/ProductsList";
import {Signup,Login } from './components/login/Login';
import { Cart } from './components/cart/Cart';
import Payment from './components/payment/Payment';
import CardPay from './components/payCard/CardPay';

function App () {
  return (
    <div className="App">
      <Switch>
        <Route exact path="/">
          <Home />
        </Route>
        <Route exact path="/products">
          <Products />
        </Route>
        <Route exact path="/signup">
          <Signup />
        </Route>
        <Route exact path="/login">
          <Login />
        </Route>
        <Route exact path="/cart">
          <Cart/>
        </Route>
        <Route path="/products/:id">
          <Item />
        </Route>
        <Route path="/checkout"><Payment/></Route>
        <Route path="/payment"><CardPay/></Route>
      </Switch>
    </div>
  );
};

export default App;
